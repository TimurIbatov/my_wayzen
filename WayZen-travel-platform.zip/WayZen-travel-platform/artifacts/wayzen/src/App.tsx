import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { ClerkProvider, SignIn, SignUp, useAuth, useClerk } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import { MapContainer, TileLayer, CircleMarker, Popup, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import {
  getGetGeminiConversationQueryKey,
  getGetOverviewQueryKey, getGetPlaceQueryKey, getGetProfileQueryKey,
  getGetStorageObjectUrl,
  getGetTripQueryKey, getHealthCheckQueryKey, getListAdminPlacesQueryKey,
  getListFavoritesQueryKey, getListGeminiConversationsQueryKey,
  getListPlacesQueryKey, getListTripsQueryKey, getSendGeminiMessageUrl,
  useActivateDemoTripPass, useAddFavorite, useCreateGeminiConversation,
  useCreatePlace, useCreateTrip, useDeleteGeminiConversation, useDeletePlace,
  useDeleteTrip, useGenerateAiRoute, useGetGeminiConversation, useGetOverview,
  useGetPlace, useGetProfile, useGetTrip, useHealthCheck, useListAdminPlaces,
  useListFavorites, useListGeminiConversations, useListPlaces, useListTrips,
  useRemoveFavorite, useRequestUploadUrl, useUpdatePlace, useUpdateProfile, useUpdateTrip,
} from '@workspace/api-client-react';
import type {
  Conversation, GeneratedRoute, Place, PlaceInput,
  PlaceUpdate, Profile, ProfileInput, Trip, TripDay, TripInput, TripUpdate,
} from '@workspace/api-client-react';
import { Link, Redirect, Route, Switch, Router as WouterRouter, useLocation, useRoute } from 'wouter';
import { useForm } from 'react-hook-form';
import {
  Form, FormControl, FormField, FormItem, FormLabel, FormMessage,
} from '@/components/ui/form';
import {
  ArrowDown, ArrowLeft, ArrowRight, Bookmark, Check, ChevronRight,
  CircleHelp, Compass, ExternalLink, Heart, LoaderCircle, Map as MapIcon,
  MapPin, MessageCircle, Plus, Search, Send, ShieldAlert, Sparkles, Trash2, X,
} from 'lucide-react';

const queryClient = new QueryClient({
  defaultOptions: { queries: { staleTime: 30_000, retry: 1, refetchOnWindowFocus: false } },
});
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
const clerkPubKey = publishableKeyFromHost(window.location.hostname, import.meta.env.VITE_CLERK_PUBLISHABLE_KEY);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
if (!clerkPubKey) throw new Error('Missing VITE_CLERK_PUBLISHABLE_KEY');
const stripBase = (path: string) => basePath && path.startsWith(basePath) ? path.slice(basePath.length) || '/' : path;
const interestsList = ['Природа', 'Наследие', 'Ремёсла', 'Еда и рынки', 'Местный быт'];
const categoryNames: Record<string, string> = {
  nature: 'Природа', heritage: 'Наследие', crafts: 'Ремёсла', food: 'Еда и рынки', local_life: 'Местный быт',
};
const showErrorText = (error: unknown) => error instanceof Error ? error.message : 'Не удалось загрузить данные. Попробуйте ещё раз.';
const safeRead = <T,>(key: string, fallback: T): T => {
  try { const parsed = localStorage.getItem(key); return parsed ? JSON.parse(parsed) as T : fallback; } catch { return fallback; }
};
const saveLocal = (key: string, value: unknown) => { try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* Browser storage may be unavailable. */ } };
const placeName = (place: Place) => place.nameRu || place.nameEn || place.slug;

function useLocalSet(key: string) {
  const [values, setValues] = useState<string[]>(() => safeRead(key, []));
  useEffect(() => saveLocal(key, values), [key, values]);
  const toggle = (value: string) => setValues(current => current.includes(value) ? current.filter(item => item !== value) : [...current, value]);
  return { values, setValues, toggle };
}

function Brand() {
  return <Link href="/" className="brand" aria-label="WayZen — на главную" data-testid="link-brand">
    <span className="brand-mark"><Compass size={19} /></span><span>wayzen</span>
  </Link>;
}

function Header({ favoriteCount }: { favoriteCount: number }) {
  const [path] = useLocation();
  const { isSignedIn } = useAuth();
  const { signOut } = useClerk();
  const links = [
    ['/places', 'Места'], ['/map', 'Карта'], ['/planner', 'Планер'], ['/ai', 'AI-гид'],
    ['/trips', 'Поездки'], ['/favorites', `Избранное${favoriteCount ? ` · ${favoriteCount}` : ''}`],
  ];
  return <>
    <header className="topbar">
      <div className="top-inner">
        <Brand />
        <nav className="nav" aria-label="Основная навигация">{links.map(([href, label]) =>
          <Link key={href} href={href} className={path === href || path.startsWith(`${href}/`) ? 'active' : ''} data-testid={`nav-${href.slice(1)}`}>{label}</Link>)}
        </nav>
        <div className="top-actions">
          {isSignedIn ? <>
            <Link className="btn btn-quiet" href="/trips" data-testid="link-trips">Мои поездки</Link>
            <Link className="icon-btn" href="/profile" aria-label="Профиль" data-testid="link-profile"><Compass size={17} /></Link>
            <button className="icon-btn" type="button" onClick={() => void signOut({ redirectUrl: basePath || '/' })} aria-label="Выйти" data-testid="button-sign-out"><ArrowDown size={17} /></button>
          </> : <><Link className="btn btn-quiet" href="/sign-in" data-testid="link-sign-in">Войти</Link><Link className="btn btn-primary" href="/sign-up" data-testid="link-sign-up">Создать аккаунт</Link></>}
        </div>
      </div>
    </header>
    <nav className="mobile-nav" aria-label="Навигация для телефона">{links.filter(([href]) => href !== '/trips').map(([href, label], index) => {
      const Icon = [MapPin, MapIcon, Sparkles, MessageCircle, Heart][index];
      return <Link key={href} href={href} className={path === href || path.startsWith(`${href}/`) ? 'active' : ''} data-testid={`mobile-nav-${href.slice(1)}`}><Icon size={18} /><span>{label.split(' ·')[0]}</span></Link>;
    })}</nav>
  </>;
}

function ArchiveNotice({ compact = false }: { compact?: boolean }) {
  return <div className="notice" role="note" data-testid="notice-preliminary-archive">
    <ShieldAlert size={18} />
    <span>{compact
      ? 'WayZen’s imported archive contains 16 preliminary records. None is verified yet. Confirm access and current conditions with reliable local sources before setting out.'
      : 'WayZen’s 16 imported archive locations are preliminary, not verified. This is a starting point for independent research—not a current guide. Opening hours, prices, safety, access and exact journey times are not confirmed here; check with reliable local sources before travelling.'}</span>
  </div>;
}

function PlaceArtwork({ place, onFavorite, saved, index = 0 }: { place: Place; onFavorite?: () => void; saved?: boolean; index?: number }) {
  const image = place.imageUrls?.find(url => Boolean(url));
  return <div className="place-image">
    {image ? <img src={image} alt={placeName(place)} loading="lazy" onError={event => { event.currentTarget.style.display = 'none'; }} /> : <div className={`art-fallback art-${index % 5}`} aria-hidden="true" />}
    <span className="image-label">WAYZEN / {String(index + 1).padStart(2, '0')}</span>
    {onFavorite && <button className="icon-btn" type="button" onClick={onFavorite} aria-label={saved ? 'Remove from favorites' : 'Save place'} data-testid={`button-favorite-${place.slug}`}><Heart size={17} fill={saved ? 'currentColor' : 'none'} /></button>}
  </div>;
}

function PlaceCard({ place, index, saved, onSave }: { place: Place; index: number; saved: boolean; onSave: () => void }) {
  return <article className="place-card" data-testid={`card-place-${place.slug}`}>
    <PlaceArtwork place={place} index={index} saved={saved} onFavorite={onSave} />
    <div className="card-body">
      <Link href={`/place/${place.slug}`} data-testid={`link-place-${place.slug}`}><h3>{placeName(place)}</h3></Link>
      <div className="card-meta"><span className="tag">{categoryNames[place.category] ?? place.category}</span><span>{place.region}</span></div>
      <div style={{ marginTop: 10 }}><span className="unverified"><ShieldAlert size={12} />Предварительно · не проверено</span></div>
    </div>
  </article>;
}

function LoadingCards({ count = 6 }: { count?: number }) {
  return <div className="results-grid" role="status" aria-label="Загружаем места" data-testid="status-places-loading">{Array.from({ length: count }, (_, i) =>
    <div className="sk-card" key={i}><div className="skeleton sk-line" /><div className="skeleton sk-line short" /></div>)}</div>;
}

function LoadError({ onRetry, error }: { onRetry: () => void; error: unknown }) {
  return <div className="error-card" role="alert" data-testid="status-load-error"><span>{showErrorText(error)}</span><button className="btn btn-quiet" onClick={onRetry} data-testid="button-retry">Попробовать снова</button></div>;
}

function Home() {
  const overview = useGetOverview({ query: { queryKey: getGetOverviewQueryKey() } });
  const places = useListPlaces(undefined, { query: { queryKey: getListPlacesQueryKey(), staleTime: 45_000 } });
  const { isSignedIn } = useAuth();
  const featured = overview.data?.featuredPlaces?.length ? overview.data.featuredPlaces : places.data?.slice(0, 3) ?? [];
  const favorites = useFavoritesState();
  return <main className="wrap">
    <section className="hero" data-testid="home-hero">
      <img src={`${import.meta.env.BASE_URL}uzbekistan-dusk.jpg`} alt="" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', zIndex: -2, opacity: .55, mixBlendMode: 'soft-light' }} />
      <div className="hero-copy"><span className="eyebrow">Узбекистан · собственным маршрутом</span>
        <h1>Ближе к тихой<br /><em>стороне страны.</em></h1>
        <p>Ищите места за пределами очевидного маршрута. Узнавайте истории, сохраняйте находки и превращайте их в поездку, которую удобно спланировать самому.</p>
        <div className="hero-actions"><Link className="btn btn-primary" href="/places" data-testid="link-explore-places">Открыть атлас <ArrowRight size={16} /></Link><Link className="btn btn-quiet" href="/planner" data-testid="link-start-planner">Собрать поездку <Sparkles size={16} /></Link></div>
      </div>
      <span className="hero-stamp">AN OPEN ARCHIVE · UZBEKISTAN</span>
    </section>
    <div style={{ marginTop: 20 }}><ArchiveNotice compact /></div>
    <section className="section">
      <div className="section-head"><div><span className="eyebrow">Начните с любопытства</span><h2>Несколько мест из архива</h2></div><Link href="/places" className="btn btn-quiet" data-testid="link-all-places">Все места <ArrowRight size={15} /></Link></div>
      {places.isLoading ? <LoadingCards count={3} /> : places.isError ? <LoadError error={places.error} onRetry={() => void places.refetch()} /> :
        featured.length ? <div className="place-grid">{featured.map((place, i) => <PlaceCard key={place.slug} place={place} index={i} saved={favorites.values.includes(place.slug)} onSave={() => favorites.toggle(place.slug)} />)}</div> :
          <EmptyState icon={<MapPin size={22} />} title="Каталог пока пуст" copy="Когда архивные записи появятся в каталоге, они будут доступны здесь." />}
    </section>
    <section className="feature-band"><div><span className="eyebrow">Не готовый тур. Хорошая отправная точка.</span><h2>Собирайте идеи. Проверяйте детали сами.</h2><p>WayZen помогает ориентироваться в предварительной подборке мест, но не подменяет актуальные местные источники. Маршруты показывают порядок остановок, а не подтверждённый график поездки.</p></div><div className="feature-actions"><Link href="/map" className="btn btn-quiet" data-testid="link-home-map">Смотреть карту</Link><Link href="/trips" className="btn btn-quiet" data-testid="link-home-trips">Мои поездки</Link><Link href="/ai" className="btn btn-primary" data-testid="link-home-ai">Спросить AI-гид <ArrowRight size={15} /></Link></div></section>
    <Footer />
    {isSignedIn && <Redirect to="/user-portal" />}
  </main>;
}

function useFavoritesState() {
  const { isSignedIn } = useAuth();
  const guest = useLocalSet('wayzen-favorites');
  const client = useQueryClient();
  const cloud = useListFavorites({ query: { queryKey: getListFavoritesQueryKey(), enabled: Boolean(isSignedIn), staleTime: 20_000 } });
  const add = useAddFavorite({ mutation: { onSuccess: () => void client.invalidateQueries({ queryKey: getListFavoritesQueryKey() }) } });
  const remove = useRemoveFavorite({ mutation: { onSuccess: () => void client.invalidateQueries({ queryKey: getListFavoritesQueryKey() }) } });
  const values = isSignedIn ? cloud.data?.map(favorite => favorite.placeSlug) ?? [] : guest.values;
  const toggle = (slug: string) => {
    if (!isSignedIn) { guest.toggle(slug); return; }
    if (values.includes(slug)) remove.mutate({ slug }); else add.mutate({ data: { placeSlug: slug } });
  };
  return { values, toggle, loading: Boolean(isSignedIn && cloud.isLoading), error: isSignedIn ? cloud.error : null, retry: () => void cloud.refetch() };
}

function EmptyState({ icon, title, copy, action }: { icon: ReactNode; title: string; copy: string; action?: ReactNode }) {
  return <div className="empty" data-testid="empty-state"><div className="empty-icon">{icon}</div><h2>{title}</h2><p>{copy}</p>{action}</div>;
}

function Catalog() {
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [region, setRegion] = useState('');
  const favorites = useFavoritesState();
  const params = useMemo(() => ({ ...(search.trim() ? { search: search.trim() } : {}), ...(category ? { category } : {}), ...(region ? { region } : {}) }), [search, category, region]);
  const places = useListPlaces(params, { query: { queryKey: getListPlacesQueryKey(params), staleTime: 30_000 } });
  const categories = Array.from(new Set(places.data?.map(place => place.category) ?? []));
  const regions = Array.from(new Set(places.data?.map(place => place.region) ?? []));
  return <main className="wrap">
    <div className="intro"><span className="eyebrow">Архив WayZen · поиск</span><h1 className="display">Места для своего пути.</h1><p>Ищите по имени, региону или категории. Ни одна из 16 импортированных точек пока не подтверждена как актуальная.</p></div>
    <ArchiveNotice />
    <div className="page-grid" style={{ marginTop: 20 }}>
      <aside className="filters" aria-label="Фильтры каталога">
        <label className="field-label">Поиск<div className="search-field"><Search size={17} /><input className="field" value={search} onChange={event => setSearch(event.target.value)} placeholder="Название или ключевое слово" data-testid="input-place-search" /></div></label>
        <label className="field-label">Категория<select className="select" value={category} onChange={event => setCategory(event.target.value)} data-testid="select-category"><option value="">Все категории</option>{categories.map(value => <option key={value} value={value}>{categoryNames[value] ?? value}</option>)}</select></label>
        <label className="field-label">Область<select className="select" value={region} onChange={event => setRegion(event.target.value)} data-testid="select-region"><option value="">Все области</option>{regions.map(value => <option key={value}>{value}</option>)}</select></label>
        <button className="btn btn-quiet" onClick={() => { setSearch(''); setCategory(''); setRegion(''); }} data-testid="button-clear-filters"><X size={15} /> Сбросить фильтры</button>
      </aside>
      <section>
        <div className="results-head"><span data-testid="text-result-count">{places.data?.length ?? 0} мест в текущем поиске</span><Link href="/map" className="btn btn-quiet" data-testid="link-catalog-map"><MapIcon size={15} /> На карте</Link></div>
        {places.isLoading ? <LoadingCards /> : places.isError ? <LoadError error={places.error} onRetry={() => void places.refetch()} /> :
          places.data?.length ? <div className="results-grid">{places.data.map((place, i) => <PlaceCard key={place.slug} place={place} index={i} saved={favorites.values.includes(place.slug)} onSave={() => favorites.toggle(place.slug)} />)}</div> :
            <EmptyState icon={<Search size={22} />} title="Ничего не нашлось" copy="Попробуйте другое слово или снимите часть фильтров." action={<button className="btn btn-quiet" onClick={() => { setSearch(''); setCategory(''); setRegion(''); }} data-testid="button-reset-search">Сбросить поиск</button>} />}
      </section>
    </div>
    <Footer />
  </main>;
}

function PlaceDetail() {
  const [, params] = useRoute('/place/:slug');
  const [, setLocation] = useLocation();
  const place = useGetPlace(params?.slug ?? '', { query: { queryKey: getGetPlaceQueryKey(params?.slug ?? ''), enabled: Boolean(params?.slug) } });
  const favorites = useFavoritesState();
  const [message, setMessage] = useState('');
  if (place.isLoading) return <main className="wrap load-shell"><div className="skeleton" style={{ height: 280, borderRadius: 22 }} /><div className="skeleton" style={{ height: 170, marginTop: 18, borderRadius: 18 }} /></main>;
  if (place.isError) return <main className="wrap load-shell"><LoadError error={place.error} onRetry={() => void place.refetch()} /></main>;
  if (!place.data) return <main className="wrap load-shell"><EmptyState icon={<MapPin />} title="Место не найдено" copy="Этой записи нет в доступном архиве." action={<Link className="btn btn-primary" href="/places">К каталогу</Link>} /></main>;
  const item = place.data;
  const category = categoryNames[item.category] ?? item.category;
  return <main className="wrap">
    <div className="intro" style={{ paddingBottom: 16 }}><Link className="btn btn-quiet" href="/places" data-testid="link-back-catalog"><ArrowLeft size={15} />К каталогу</Link></div>
    <section className="detail-hero"><div><span className="eyebrow" style={{ color: '#f0cf9c' }}>{category} · {item.region}</span><h1>{placeName(item)}</h1></div></section>
    <div className="detail-layout">
      <section className="detail-copy">
        <span className="unverified"><ShieldAlert size={13} />Предварительная запись · не проверено</span>
        {item.imageUrls.length > 0 ? <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(190px, 1fr))', gap: 10, margin: '18px 0' }} data-testid="place-photo-gallery">
          {item.imageUrls.map((url, index) => <img key={`${url}-${index}`} src={url} alt={`${placeName(item)} · фото ${index + 1}`} loading="lazy" style={{ width: '100%', height: 220, objectFit: 'cover', borderRadius: 14, background: '#e6e9e2' }} onError={event => { event.currentTarget.style.display = 'none'; }} />)}
        </div> : <div className="art-fallback art-0" role="img" aria-label="Фотография пока не добавлена" style={{ minHeight: 180, borderRadius: 14, margin: '18px 0', display: 'grid', placeItems: 'center', color: '#48634f' }}>Фотография пока не добавлена</div>}
        <h2>{item.kind}</h2>
        <p>{item.summaryRu || item.summaryEn || 'Для этой записи пока нет краткого описания.'}</p>
        <p>{item.storyRu || item.storyEn || 'Дополнительный архивный рассказ для этой записи пока не добавлен.'}</p>
        <ArchiveNotice />
        <h2>Практические заметки</h2><p>{item.practicalNotesRu || item.practicalNotesEn || 'Архив не содержит подтверждённых практических сведений для этой точки.'}</p>
        <p>Координаты и материалы взяты из архивной записи. Мы не подтверждаем текущий доступ, безопасность, правила посещения, сезонность, часы работы, стоимость или время в пути. Проверьте всё отдельно перед поездкой.</p>
        <h2>Источники записи и фото</h2><p style={{ whiteSpace: 'pre-wrap', overflowWrap: 'anywhere' }}>{item.source || 'Для этой записи пока не указан источник.'}</p>
        {message && <p role="status" data-testid="status-place-added">{message}</p>}
      </section>
      <aside className="detail-side">
        <span className="eyebrow">Архивные координаты</span><span className="coords">{item.latitude.toFixed(5)}, {item.longitude.toFixed(5)}</span>
        <a className="btn btn-primary" href={`https://www.openstreetmap.org/?mlat=${item.latitude}&mlon=${item.longitude}#map=10/${item.latitude}/${item.longitude}`} target="_blank" rel="noreferrer" data-testid="link-open-osm">Посмотреть район <ExternalLink size={15} /></a>
        <button className="btn btn-quiet" onClick={() => favorites.toggle(item.slug)} data-testid="button-detail-favorite">{favorites.values.includes(item.slug) ? <Check size={15} /> : <Heart size={15} />}{favorites.values.includes(item.slug) ? 'В избранном' : 'Сохранить место'}</button>
        <button className="btn btn-quiet" onClick={() => { const stops = safeRead<string[]>('wayzen-planner-stops', []); if (!stops.includes(item.slug)) saveLocal('wayzen-planner-stops', [...stops, item.slug]); setMessage('Добавлено в список планера на этом устройстве.'); setLocation('/planner'); }} data-testid="button-add-to-planner"><Plus size={15} />Добавить в планер</button>
      </aside>
    </div><Footer />
  </main>;
}

function MapFocus({ place }: { place?: Place }) {
  const map = useMap();
  useEffect(() => { if (place) map.flyTo([place.latitude, place.longitude], Math.max(map.getZoom(), 8), { duration: .65 }); }, [place, map]);
  return null;
}

function MapPage() {
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [region, setRegion] = useState('');
  const [selectedSlug, setSelectedSlug] = useState('');
  const params = useMemo(() => ({ ...(search.trim() ? { search: search.trim() } : {}), ...(category ? { category } : {}), ...(region ? { region } : {}) }), [search, category, region]);
  const places = useListPlaces(params, { query: { queryKey: getListPlacesQueryKey(params) } });
  const selected = places.data?.find(place => place.slug === selectedSlug);
  return <main className="wrap">
    <div className="intro"><span className="eyebrow">Географический ориентир</span><h1 className="display">Найти место на карте.</h1><p>Реальная интерактивная карта с архивными координатами. Точки помогают увидеть расположение, но не показывают маршрут, доступ или условия посещения.</p></div>
    <ArchiveNotice compact />
    <div className="map-page" style={{ marginTop: 18 }}>
      <aside className="map-panel">
        <div className="search-field"><Search size={16} /><input className="field" value={search} onChange={event => setSearch(event.target.value)} placeholder="Найти в архиве" aria-label="Поиск на карте" data-testid="input-map-search" /></div>
        <select className="select" value={category} onChange={event => setCategory(event.target.value)} aria-label="Фильтр по категории" data-testid="select-map-category"><option value="">Все категории</option>{Array.from(new Set(places.data?.map(place => place.category) ?? [])).map(option => <option key={option}>{option}</option>)}</select>
        <select className="select" value={region} onChange={event => setRegion(event.target.value)} aria-label="Фильтр по области" data-testid="select-map-region"><option value="">Все области</option>{Array.from(new Set(places.data?.map(place => place.region) ?? [])).map(option => <option key={option}>{option}</option>)}</select>
        <div className="map-results" data-testid="map-place-list">
          {places.isLoading ? <div className="skeleton" style={{ height: 110 }} /> : places.isError ? <LoadError error={places.error} onRetry={() => void places.refetch()} /> :
            places.data?.length ? places.data.map(place => <button className={`map-row ${selectedSlug === place.slug ? 'selected' : ''}`} key={place.slug} onClick={() => setSelectedSlug(place.slug)} data-testid={`map-list-${place.slug}`}><i className="map-dot" /><span className="map-row-copy"><strong>{placeName(place)}</strong><span>{place.region} · {categoryNames[place.category] ?? place.category}</span></span><ChevronRight size={15} /></button>) :
              <EmptyState icon={<MapPin size={20} />} title="Нет точек" copy="Измените поиск или фильтры." />}
        </div>
      </aside>
      <section className="map-canvas" aria-label="Карта Узбекистана и мест архива" data-testid="interactive-map">
        <MapContainer center={[41.1, 64.4]} zoom={5} scrollWheelZoom={true} style={{ height: '100%', minHeight: 600, width: '100%', zIndex: 1 }} attributionControl>
          <TileLayer attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors' url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
          <MapFocus place={selected} />
          {places.data?.map(place => <CircleMarker key={place.slug} center={[place.latitude, place.longitude]} radius={selectedSlug === place.slug ? 9 : 6} pathOptions={{ color: '#fff8e8', weight: 2, fillColor: selectedSlug === place.slug ? '#b55f45' : '#1c6556', fillOpacity: .95 }} eventHandlers={{ click: () => setSelectedSlug(place.slug) }}><Popup><strong>{placeName(place)}</strong><br />{place.region}<br /><a href={`${basePath}/place/${place.slug}`}>Открыть запись</a></Popup></CircleMarker>)}
        </MapContainer>
        <div className="map-disclaimer" data-testid="text-map-caveat">Архивные координаты — только ориентир. Проверяйте доступ и условия самостоятельно; WayZen не сообщает точное время в пути.</div>
      </section>
    </div><Footer />
  </main>;
}

type PlannerValues = { days: number; interests: string[]; region: string; pace: 'slow' | 'balanced' | 'packed'; budget: 'budget' | 'moderate' | 'comfort' };
function Planner() {
  const form = useForm<PlannerValues>({ defaultValues: { days: 2, interests: ['Природа'], region: '', pace: 'slow', budget: 'moderate' } });
  const generated = useGenerateAiRoute();
  const createTrip = useTripCreate();
  const { isSignedIn } = useAuth();
  const plannerProfile = useGetProfile({ query: { queryKey: getGetProfileQueryKey(), enabled: Boolean(isSignedIn) } });
  const localStops = useLocalSet('wayzen-planner-stops');
  const places = useListPlaces(undefined, { query: { queryKey: getListPlacesQueryKey() } });
  const route = generated.data as GeneratedRoute | undefined;
  const stopPlaces = useMemo(() => (route?.days ?? []).flatMap(day => day.stops).map(stop => places.data?.find(place => place.slug === stop.placeSlug)).filter((place): place is Place => Boolean(place)), [route, places.data]);
  const submit = form.handleSubmit(values => generated.mutate({ data: { days: Number(values.days), interests: values.interests, ...(values.region ? { region: values.region } : {}), pace: values.pace, budget: values.budget, ...(!isSignedIn ? { anonymousId: getAnonymousId() } : {}) } }));
  const saveRoute = () => {
    if (!route) return;
    const data: TripInput = { title: route.title, notes: route.disclaimer, days: route.days };
    if (isSignedIn) createTrip.mutate(data); else {
      const localTrips = safeRead<Trip[]>('wayzen-local-trips', []);
      const now = new Date().toISOString();
      saveLocal('wayzen-local-trips', [{ ...data, id: Date.now(), createdAt: now, updatedAt: now }, ...localTrips]);
      localStops.setValues(route.days.flatMap(day => day.stops.map(stop => stop.placeSlug)));
    }
  };
  return <main className="wrap">
    <div className="intro"><span className="eyebrow">Маршрутный стол</span><h1 className="display">Соберите поездку, не угадывая.</h1><p>WayZen предложит последовательность остановок по архиву. Любые примерные минуты не являются подтверждённым временем в пути или планом доступа.</p></div>
    <ArchiveNotice />
    <div className="planner-layout" style={{ marginTop: 19 }}>
      <section className="panel route-panel">
        <h2>Пожелания к поездке</h2><p>Параметры помогают составить идею, а не бронирование или подтверждённый маршрут.</p>
        <Form {...form}><form onSubmit={submit} data-testid="form-generate-route">
          <div className="form-grid">
            <FormField control={form.control} name="days" render={({ field }) => <FormItem className="field-label"><FormLabel>Дней · от 1 до 7</FormLabel><FormControl><input className="field" type="number" min={1} max={7} {...field} onChange={event => field.onChange(Number(event.target.value))} data-testid="input-route-days" /></FormControl><FormMessage /></FormItem>} />
            <FormField control={form.control} name="region" render={({ field }) => <FormItem className="field-label"><FormLabel>Область, если есть предпочтение</FormLabel><FormControl><select className="select" {...field} data-testid="select-route-region"><option value="">Без фильтра</option>{Array.from(new Set(places.data?.map(place => place.region) ?? [])).map(item => <option key={item}>{item}</option>)}</select></FormControl></FormItem>} />
            <FormField control={form.control} name="pace" render={({ field }) => <FormItem className="field-label"><FormLabel>Темп поездки</FormLabel><FormControl><select className="select" {...field} data-testid="select-route-pace"><option value="slow">Неторопливый</option><option value="balanced">Сбалансированный</option><option value="packed">Насыщенный</option></select></FormControl></FormItem>} />
            <FormField control={form.control} name="budget" render={({ field }) => <FormItem className="field-label"><FormLabel>Бюджетный профиль</FormLabel><FormControl><select className="select" {...field} data-testid="select-route-budget"><option value="budget">Бюджетный</option><option value="moderate">Умеренный</option><option value="comfort">Комфорт</option></select></FormControl></FormItem>} />
          </div>
          <FormField control={form.control} name="interests" render={({ field }) => <FormItem className="field-label"><FormLabel>Интересы</FormLabel><div className="check-row">{interestsList.map(item => <label key={item} className="check-chip"><input type="checkbox" checked={field.value.includes(item)} onChange={event => field.onChange(event.target.checked ? [...field.value, item] : field.value.filter(value => value !== item))} data-testid={`check-interest-${item}`} />{item}</label>)}</div></FormItem>} />
          <button className="btn btn-primary" style={{ marginTop: 18 }} type="submit" disabled={generated.isPending} data-testid="button-generate-route">{generated.isPending ? <LoaderCircle size={16} className="animate-spin" /> : <Sparkles size={16} />}Предложить маршрут</button>
        </form></Form>
        {generated.isError && <div style={{ marginTop: 14 }}><LoadError error={generated.error} onRetry={() => void submit()} /></div>}
        {route && <section className="day-card" data-testid="generated-route"><div className="section-head" style={{ marginBottom: 9 }}><div><span className="eyebrow">Черновая идея</span><h3 style={{ marginTop: 6 }}>{route.title}</h3></div><button className="btn btn-quiet" onClick={saveRoute} disabled={createTrip.loading} data-testid="button-save-generated-trip"><Bookmark size={15} />{createTrip.loading ? 'Сохраняем…' : 'Сохранить поездку'}</button></div>
          {route.days.map(day => <DayStops key={day.day} day={day} places={places.data ?? []} />)}
          <p data-testid="text-route-disclaimer"><strong>Уточнение:</strong> {route.disclaimer} Указанное время не подтверждает точное время в пути.</p>
          <span className="unverified">Примерная длительность: {route.approximateTotalMinutes} мин · оценка, не расписание</span>
        </section>}
        {!route && !generated.isPending && <EmptyState icon={<Compass size={21} />} title="Маршрут начнётся с ваших интересов" copy="Настройте пожелания выше. WayZen создаст предварительный план из доступных архивных записей." />}
      </section>
      <aside className="panel"><span className="eyebrow">Без ложных обещаний</span><h3 style={{ marginTop: 8 }}>План — только отправная точка.</h3><p>Минуты и порядок — приблизительная оценка, не навигация. Актуальные условия, часы или стоимость неизвестны.</p><p data-testid="text-route-quota"><strong>{plannerProfile.data?.aiRoutesLimit === -1 ? 'Trip Pass: без дневного лимита' : 'Free: 1 AI-маршрут за день по Самарканду'}</strong>{plannerProfile.data && plannerProfile.data.aiRoutesLimit !== -1 ? ` · сегодня ${plannerProfile.data.aiRoutesUsedToday} из ${plannerProfile.data.aiRoutesLimit}` : ''}</p><ArchiveNotice compact /><div style={{ marginTop: 15 }}><Link className="btn btn-quiet" href="/places" data-testid="link-planner-catalog">Выбрать места вручную <ArrowRight size={15} /></Link></div></aside>
    </div><Footer />
  </main>;
}

function getAnonymousId() {
  const key = 'wayzen-anonymous-id';
  let id = safeRead<string>(key, '');
  if (!id) { id = `guest-${crypto.randomUUID()}`; saveLocal(key, id); }
  return id;
}

function DayStops({ day, places }: { day: TripDay; places: Place[] }) {
  return <article className="day-card"><h3>День {day.day} · {day.theme}</h3>{day.stops.map(stop => {
    const place = places.find(item => item.slug === stop.placeSlug);
    return <div className="stop-line" key={`${day.day}-${stop.order}-${stop.placeSlug}`}><span className="stop-order">{stop.order}</span><span><strong>{place ? placeName(place) : stop.placeSlug}</strong><small>Оценка пути {stop.estimatedTravelMinutes} мин · рекомендуемое посещение {stop.suggestedVisitMinutes} мин. Не проверено.</small>{stop.note && <small> · {stop.note}</small>}</span></div>;
  })}</article>;
}

function useTripCreate() {
  const client = useQueryClient();
  const mutation = useCreateTrip({ mutation: { onSuccess: () => void client.invalidateQueries({ queryKey: getListTripsQueryKey() }) } });
  return { mutate: (data: TripInput) => mutation.mutate({ data }), loading: mutation.isPending, error: mutation.error };
}

function Favorites() {
  const { isSignedIn } = useAuth();
  const favorites = useFavoritesState();
  const places = useListPlaces(undefined, { query: { queryKey: getListPlacesQueryKey() } });
  const saved = places.data?.filter(place => favorites.values.includes(place.slug)) ?? [];
  return <main className="wrap">
    <div className="intro"><span className="eyebrow">Под рукой</span><h1 className="display">Ваши сохранённые места.</h1><p>{isSignedIn ? 'Избранное синхронизируется с аккаунтом.' : 'Гостевое избранное хранится в браузере на этом устройстве.'}</p></div>
    <ArchiveNotice compact />
    {favorites.loading || places.isLoading ? <LoadingCards count={3} /> : favorites.error ? <LoadError error={favorites.error} onRetry={favorites.retry} /> : places.isError ? <LoadError error={places.error} onRetry={() => void places.refetch()} /> :
      saved.length ? <section className="section"><div className="place-grid">{saved.map((place, i) => <PlaceCard key={place.slug} place={place} index={i} saved onSave={() => favorites.toggle(place.slug)} />)}</div></section> :
        <div style={{ marginTop: 20 }}><EmptyState icon={<Heart size={22} />} title="Пока ничего не сохранено" copy="Откройте каталог и добавьте места, которые хотите изучить." action={<Link className="btn btn-primary" href="/places">Найти места <ArrowRight size={15} /></Link>} /></div>}
    <Footer />
  </main>;
}

function useTripData() {
  const { isSignedIn } = useAuth();
  const client = useQueryClient();
  const query = useListTrips({ query: { queryKey: getListTripsQueryKey(), enabled: Boolean(isSignedIn), staleTime: 20_000 } });
  const [guestTrips, setGuestTrips] = useState<Trip[]>(() => safeRead('wayzen-local-trips', []));
  const remove = useDeleteTrip({ mutation: { onSuccess: () => void client.invalidateQueries({ queryKey: getListTripsQueryKey() }) } });
  const deleteTrip = (id: number) => isSignedIn ? remove.mutate({ id }) : setGuestTrips(current => { const next = current.filter(trip => trip.id !== id); saveLocal('wayzen-local-trips', next); return next; });
  return { trips: isSignedIn ? query.data ?? [] : guestTrips, isSignedIn, loading: Boolean(isSignedIn && query.isLoading), error: isSignedIn ? query.error : null, retry: () => void query.refetch(), deleteTrip, deleting: remove.isPending };
}

function Trips() {
  const data = useTripData();
  return <main className="wrap">
    <div className="intro"><span className="eyebrow">Сохранённые планы</span><h1 className="display">Поездки, которые ждут.</h1><p>{data.isSignedIn ? 'Поездки синхронизируются с вашим аккаунтом.' : 'Гостевые поездки хранятся локально в браузере. Войдите, чтобы использовать облачное хранилище.'}</p></div>
    <ArchiveNotice compact />
    {data.loading ? <div className="load-shell"><div className="skeleton" style={{ height: 88, marginBottom: 10 }} /><div className="skeleton" style={{ height: 88 }} /></div> : data.error ? <div style={{ marginTop: 18 }}><LoadError error={data.error} onRetry={data.retry} /></div> :
      data.trips.length ? <section className="section">{data.trips.map((trip, index) => <div className="trip-row" key={trip.id} data-testid={`trip-row-${trip.id}`}><span className="trip-index">{String(index + 1).padStart(2, '0')}</span><Link className="trip-copy" href={`/trips/${trip.id}`} data-testid={`link-trip-${trip.id}`}><strong>{trip.title}</strong><span>{trip.days.length} дней · {trip.days.reduce((count, day) => count + day.stops.length, 0)} остановок</span></Link><Link className="btn btn-quiet" href={`/trips/${trip.id}`} data-testid={`button-open-trip-${trip.id}`}>Открыть</Link><button className="icon-btn" aria-label="Удалить поездку" onClick={() => { if (window.confirm('Удалить эту поездку?')) data.deleteTrip(trip.id); }} data-testid={`button-delete-trip-${trip.id}`}><Trash2 size={16} /></button></div>)}</section> :
        <div style={{ marginTop: 20 }}><EmptyState icon={<Bookmark size={21} />} title="Список пока пуст" copy="Сохраните маршрут из планера — он появится здесь." action={<Link className="btn btn-primary" href="/planner" data-testid="link-start-planning">Открыть планер <ArrowRight size={15} /></Link>} /></div>}
    {!data.isSignedIn && <div style={{ marginTop: 16 }}><Link className="btn btn-quiet" href="/sign-in" data-testid="link-sync-trips">Войти для облачной синхронизации</Link></div>}
    <Footer />
  </main>;
}

function TripDetail() {
  const [, params] = useRoute('/trips/:id');
  const id = Number(params?.id);
  const { isSignedIn } = useAuth();
  const client = useQueryClient();
  const cloudTrip = useGetTrip(id, { query: { queryKey: getGetTripQueryKey(id), enabled: Boolean(isSignedIn && Number.isFinite(id)) } });
  const [guestTrips, setGuestTrips] = useState<Trip[]>(() => safeRead('wayzen-local-trips', []));
  const trip = isSignedIn ? cloudTrip.data : guestTrips.find(item => item.id === id);
  const form = useForm<{ title: string; notes: string }>({ defaultValues: { title: '', notes: '' } });
  useEffect(() => { if (trip) form.reset({ title: trip.title, notes: trip.notes }); }, [trip?.id, trip?.updatedAt, form]);
  const update = useUpdateTrip({ mutation: { onSuccess: () => { void client.invalidateQueries({ queryKey: getGetTripQueryKey(id) }); void client.invalidateQueries({ queryKey: getListTripsQueryKey() }); } } });
  const places = useListPlaces(undefined, { query: { queryKey: getListPlacesQueryKey() } });
  const onSubmit = form.handleSubmit(value => {
    if (!trip) return;
    const patch: TripUpdate = { title: value.title.trim(), notes: value.notes };
    if (isSignedIn) update.mutate({ id, data: patch });
    else { const next = guestTrips.map(item => item.id === id ? { ...item, ...patch, updatedAt: new Date().toISOString() } : item); setGuestTrips(next); saveLocal('wayzen-local-trips', next); }
  });
  if (isSignedIn && cloudTrip.isLoading) return <main className="wrap load-shell"><div className="skeleton" style={{ height: 260 }} /></main>;
  if (isSignedIn && cloudTrip.isError) return <main className="wrap load-shell"><LoadError error={cloudTrip.error} onRetry={() => void cloudTrip.refetch()} /></main>;
  if (!trip) return <main className="wrap load-shell"><EmptyState icon={<CircleHelp />} title="Поездка не найдена" copy="Возможно, она удалена или сохранена в другом браузере." action={<Link className="btn btn-primary" href="/trips">К поездкам</Link>} /></main>;
  return <main className="wrap"><div className="intro"><Link className="btn btn-quiet" href="/trips"><ArrowLeft size={15} />К поездкам</Link><h1 className="display" style={{ marginTop: 20 }}>{trip.title}</h1></div>
    <div className="planner-layout"><section className="panel"><h2>Дни поездки</h2>{trip.days.map(day => <DayStops key={day.day} day={day} places={places.data ?? []} />)}<ArchiveNotice compact /></section>
      <aside className="panel"><h3>Заметки и название</h3><Form {...form}><form onSubmit={onSubmit} data-testid="form-edit-trip"><FormField control={form.control} name="title" render={({ field }) => <FormItem className="field-label"><FormLabel>Название</FormLabel><FormControl><input className="field" maxLength={120} {...field} data-testid="input-trip-title" /></FormControl><FormMessage /></FormItem>} /><FormField control={form.control} name="notes" render={({ field }) => <FormItem className="field-label" style={{ marginTop: 12 }}><FormLabel>Заметки</FormLabel><FormControl><textarea className="textarea" maxLength={2000} {...field} data-testid="input-trip-notes" /></FormControl><FormMessage /></FormItem>} /><button className="btn btn-primary" style={{ marginTop: 14 }} type="submit" disabled={update.isPending} data-testid="button-update-trip">{update.isPending ? 'Сохраняем…' : 'Сохранить изменения'}</button></form></Form></aside>
    </div><Footer />
  </main>;
}

type ChatLine = { role: 'user' | 'assistant'; content: string };
async function streamSse(url: string, payload: unknown, onChunk: (chunk: string) => void) {
  const response = await fetch(url, { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', Accept: 'text/event-stream' }, body: JSON.stringify(payload) });
  if (!response.ok) { let message = 'Не удалось получить ответ. Попробуйте ещё раз.'; try { const body = await response.json() as { error?: string }; if (body.error) message = body.error; } catch { /* Error may not be JSON. */ } throw new Error(message); }
  if (!response.body) throw new Error('Поток ответа недоступен. Попробуйте ещё раз.');
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = ''; let completed = false;
  while (!completed) {
    const { value, done } = await reader.read();
    buffer += decoder.decode(value, { stream: !done });
    const frames = buffer.split(/\r?\n\r?\n/); buffer = frames.pop() ?? '';
    for (const frame of frames) {
      const data = frame.split(/\r?\n/).find(line => line.startsWith('data:'))?.slice(5).trim();
      if (!data) continue;
      try { const item = JSON.parse(data) as { content?: string; done?: boolean; error?: string }; if (item.content) onChunk(item.content); if (item.error) throw new Error(item.error); if (item.done) completed = true; }
      catch (error) { if (error instanceof SyntaxError) continue; throw error; }
    }
    if (done) break;
  }
  if (buffer.trim()) {
    const data = buffer.split(/\r?\n/).find(line => line.startsWith('data:'))?.slice(5).trim();
    if (data) try { const item = JSON.parse(data) as { content?: string; error?: string }; if (item.content) onChunk(item.content); if (item.error) throw new Error(item.error); } catch (error) { if (!(error instanceof SyntaxError)) throw error; }
  }
}

function AIChat() {
  const { isSignedIn } = useAuth();
  const client = useQueryClient();
  const profile = useGetProfile({ query: { queryKey: getGetProfileQueryKey(), enabled: Boolean(isSignedIn) } });
  const histories = useListGeminiConversations({ query: { queryKey: getListGeminiConversationsQueryKey(), enabled: Boolean(isSignedIn), staleTime: 15_000 } });
  const createConversation = useCreateGeminiConversation({ mutation: { onSuccess: () => void client.invalidateQueries({ queryKey: getListGeminiConversationsQueryKey() }) } });
  const deleteConversation = useDeleteGeminiConversation({ mutation: { onSuccess: () => void client.invalidateQueries({ queryKey: getListGeminiConversationsQueryKey() }) } });
  const [conversationId, setConversationId] = useState<number>();
  const conversation = useGetGeminiConversation(conversationId ?? 0, { query: { queryKey: getGetGeminiConversationQueryKey(conversationId ?? 0), enabled: Boolean(isSignedIn && conversationId) } });
  const [messages, setMessages] = useState<ChatLine[]>([]);
  const [draft, setDraft] = useState('');
  const [busy, setBusy] = useState(false);
  const [chatError, setChatError] = useState('');
  const log = useRef<HTMLDivElement>(null);
  useEffect(() => { if (conversation.data) setMessages(conversation.data.messages.map(message => ({ role: message.role, content: message.content }))); }, [conversation.data?.id, conversation.data?.updatedAt]);
  useEffect(() => { log.current?.scrollTo({ top: log.current.scrollHeight, behavior: 'smooth' }); }, [messages, busy]);
  const send = async (value = draft) => {
    const text = value.trim(); if (!text || busy || text.length > 2000) return;
    setBusy(true); setDraft(''); setChatError('');
    setMessages(current => [...current, { role: 'user', content: text }, { role: 'assistant', content: '' }]);
    try {
      let targetId = conversationId;
      if (isSignedIn && !targetId) {
        const created = await createConversation.mutateAsync({ data: { title: text.slice(0, 80) } });
        targetId = created.id;
      }
      let answer = '';
      const url = isSignedIn && targetId ? getSendGeminiMessageUrl(targetId) : '/api/wayzen/chat';
      const payload = isSignedIn && targetId ? { content: text } : { messages: [...messages, { role: 'user' as const, content: text }].slice(-12) };
      await streamSse(url, payload, chunk => {
        answer += chunk;
        setMessages(current => current.map((message, index) => index === current.length - 1 ? { ...message, content: answer } : message));
      });
      if (isSignedIn && targetId) {
        setConversationId(targetId);
        void client.invalidateQueries({ queryKey: getGetGeminiConversationQueryKey(targetId) });
        void client.invalidateQueries({ queryKey: getListGeminiConversationsQueryKey() });
        void client.invalidateQueries({ queryKey: getGetProfileQueryKey() });
      }
    } catch (error) {
      const message = showErrorText(error); setChatError(message);
      setMessages(current => current.map((item, index) => index === current.length - 1 ? { ...item, content: message } : item));
    } finally { setBusy(false); }
  };
  const startNew = () => { setConversationId(undefined); setMessages([]); setChatError(''); };
  const starters = ['Где в архиве искать тихую природу?', 'Какие места связаны с ремёслами?', 'Помоги придумать основу самостоятельной поездки.'];
  return <main className="wrap">
    <div className="intro"><span className="eyebrow">Путевой собеседник</span><h1 className="display">Спросите WayZen.</h1><p>AI работает с предварительными зацепками. Он должен явно отмечать неизвестное, а не додумывать расписания, цены, безопасность или доступ.</p></div>
    <ArchiveNotice compact />
    <div className="chat-layout" style={{ marginTop: 18 }}>
      <aside className="chat-history"><button className="btn btn-primary" onClick={startNew} data-testid="button-new-conversation"><Plus size={15} />Новый разговор</button>
        {isSignedIn ? histories.isLoading ? <div className="skeleton" style={{ height: 70 }} /> : histories.isError ? <LoadError error={histories.error} onRetry={() => void histories.refetch()} /> :
          histories.data?.map((item: Conversation) => <div style={{ display: 'flex', alignItems: 'center', gap: 4 }} key={item.id}><button className={`chat-history-item ${conversationId === item.id ? 'active' : ''}`} style={{ flex: 1 }} onClick={() => { setConversationId(item.id); setChatError(''); }} data-testid={`button-conversation-${item.id}`}>{item.title}</button><button className="icon-btn" style={{ width: 32, height: 32 }} aria-label="Удалить разговор" onClick={() => { if (window.confirm('Удалить разговор?')) { deleteConversation.mutate({ id: item.id }); if (conversationId === item.id) startNew(); } }} data-testid={`button-delete-conversation-${item.id}`}><Trash2 size={13} /></button></div>) :
            <p style={{ fontSize: 11, color: '#718077' }}>Войдите, чтобы сохранять историю разговоров в аккаунте.</p>}
      </aside>
      <section className="chat-main">
        <div className="chat-head"><span><span className="eyebrow">WayZen · AI-гид</span><br /><strong style={{ font: '600 18px var(--app-font-serif)' }}>{conversation.data?.title ?? 'Новый разговор'}</strong></span><span className="unverified">Архив предварительный</span></div>
         <div className="unverified" role="note" data-testid="text-chat-quota" style={{ margin: '10px 14px 0', justifyContent: 'center' }}>
           {!isSignedIn ? 'Гостевой AI-чат: до 10 сообщений за день по Самарканду.' : profile.data?.aiChatLimit === -1 ? 'Trip Pass: дневного лимита AI-чата нет.' : profile.data ? `Free: ${profile.data.aiChatUsedToday} из ${profile.data.aiChatLimit} сообщений за день по Самарканду.` : 'Лимит зависит от плана аккаунта.'}
         </div>
        <div className="messages" ref={log} role="log" aria-live="polite" data-testid="chat-message-list">
          {!messages.length ? <div style={{ margin: 'auto', maxWidth: 580, textAlign: 'center' }}><div className="empty-icon"><MessageCircle size={22} /></div><h2 style={{ font: '600 30px var(--app-font-serif)' }}>Ищем путь через любопытство.</h2><p style={{ color: '#6a796f', lineHeight: 1.65 }}>Расскажите, что вам интересно. Ответы — идеи для самостоятельной проверки, а не актуальные сведения о местах.</p><div style={{ display: 'grid', gap: 8, marginTop: 19 }}>{starters.map((prompt, i) => <button className="btn btn-quiet" key={prompt} onClick={() => void send(prompt)} data-testid={`button-chat-starter-${i}`}>{prompt}</button>)}</div></div> :
            messages.map((message, index) => <div key={`${index}-${message.role}`} className={`message ${message.role}`} data-testid={`chat-message-${message.role}-${index}`}>{message.content || (busy && index === messages.length - 1 ? 'Пишу ответ…' : '')}</div>)}
        </div>
        {chatError && <div className="error-card" role="alert" style={{ margin: '0 16px 12px' }} data-testid="status-chat-error">{chatError}<button className="btn btn-quiet" onClick={() => void send(messages.filter(item => item.role === 'user').at(-1)?.content ?? '')} data-testid="button-retry-chat">Повторить</button></div>}
        <form className="compose" onSubmit={event => { event.preventDefault(); void send(); }} data-testid="form-chat">
          <div className="compose-inner"><textarea value={draft} maxLength={2000} onChange={event => setDraft(event.target.value)} onKeyDown={event => { if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); void send(); } }} placeholder="Например: какие архивные места подходят для интереса к ремёслам?" aria-label="Сообщение WayZen" data-testid="input-chat-message" /><button className="btn btn-primary" type="submit" disabled={busy || !draft.trim()} aria-label="Отправить сообщение" data-testid="button-send-chat"><Send size={16} /></button></div>
          <div style={{ textAlign: 'right', color: '#78847a', fontSize: 10, paddingRight: 8 }}>{draft.length}/2000 · Shift + Enter — новая строка</div>
        </form>
      </section>
    </div><Footer />
  </main>;
}

type ProfileForm = { interests: string[]; pace: 'slow' | 'balanced' | 'packed'; budget: 'budget' | 'moderate' | 'comfort'; travelStyle: string };
function ProfilePage() {
  const { isSignedIn } = useAuth();
  const client = useQueryClient();
  const [offlinePreviewOpen, setOfflinePreviewOpen] = useState(false);
  const profile = useGetProfile({ query: { queryKey: getGetProfileQueryKey(), enabled: Boolean(isSignedIn), staleTime: 20_000 } });
  const update = useUpdateProfile({ mutation: { onSuccess: () => void client.invalidateQueries({ queryKey: getGetProfileQueryKey() }) } });
  const pass = useActivateDemoTripPass({ mutation: { onSuccess: () => void client.invalidateQueries({ queryKey: getGetProfileQueryKey() }) } });
  const form = useForm<ProfileForm>({ defaultValues: { interests: [], pace: 'slow', budget: 'moderate', travelStyle: '' } });
  useEffect(() => { if (profile.data) form.reset({ interests: profile.data.interests, pace: profile.data.pace, budget: profile.data.budget, travelStyle: profile.data.travelStyle }); }, [profile.data, form]);
  const submit = form.handleSubmit((values: ProfileInput) => update.mutate({ data: values }));
  if (!isSignedIn) return <main className="wrap load-shell"><EmptyState icon={<Compass />} title="Профиль ждёт вас" copy="Войдите, чтобы сохранить предпочтения путешествий и проверить план аккаунта." action={<Link className="btn btn-primary" href="/sign-in">Войти</Link>} /></main>;
  if (profile.isLoading) return <main className="wrap load-shell"><div className="skeleton" style={{ height: 370, borderRadius: 19 }} /></main>;
  if (profile.isError) return <main className="wrap load-shell"><LoadError error={profile.error} onRetry={() => void profile.refetch()} /></main>;
  const data = profile.data as Profile;
  return <main className="wrap">
    <div className="intro"><span className="eyebrow">Ваш WayZen</span><h1 className="display">Настройки поездок.</h1><p>Ваши предпочтения помогают формировать идеи. Мы не запрашиваем разрешения на доступ к местам и не знаем текущие условия посещения.</p></div>
    <div className="profile-grid">
      <section className="panel"><h2>Что вам интересно</h2><Form {...form}><form onSubmit={submit} data-testid="form-profile">
        <FormField control={form.control} name="interests" render={({ field }) => <FormItem className="field-label"><FormLabel>Интересы</FormLabel><div className="check-row">{interestsList.map(item => <label className="check-chip" key={item}><input type="checkbox" checked={field.value.includes(item)} onChange={event => field.onChange(event.target.checked ? [...field.value, item] : field.value.filter(value => value !== item))} data-testid={`profile-interest-${item}`} />{item}</label>)}</div></FormItem>} />
        <div className="form-grid"><FormField control={form.control} name="pace" render={({ field }) => <FormItem className="field-label"><FormLabel>Предпочтительный темп</FormLabel><FormControl><select className="select" {...field} data-testid="select-profile-pace"><option value="slow">Неторопливый</option><option value="balanced">Сбалансированный</option><option value="packed">Насыщенный</option></select></FormControl></FormItem>} /><FormField control={form.control} name="budget" render={({ field }) => <FormItem className="field-label"><FormLabel>Бюджетный профиль</FormLabel><FormControl><select className="select" {...field} data-testid="select-profile-budget"><option value="budget">Бюджетный</option><option value="moderate">Умеренный</option><option value="comfort">Комфорт</option></select></FormControl></FormItem>} /></div>
        <FormField control={form.control} name="travelStyle" render={({ field }) => <FormItem className="field-label"><FormLabel>Какой вы путешественник?</FormLabel><FormControl><textarea className="textarea" maxLength={240} {...field} placeholder="Напишите пару ориентиров, не личных данных" data-testid="input-travel-style" /></FormControl><FormMessage /></FormItem>} />
        <button className="btn btn-primary" style={{ marginTop: 18 }} type="submit" disabled={update.isPending} data-testid="button-save-profile">{update.isPending ? 'Сохраняем…' : 'Сохранить предпочтения'}</button>
      </form></Form></section>
      <aside className="status-card"><span className="eyebrow">План аккаунта</span><p><strong>{data.plan === 'trip_pass' ? 'Trip Pass' : 'Free'}</strong></p><p>AI-маршруты сегодня: {data.aiRoutesLimit < 0 ? 'без дневного лимита' : `${data.aiRoutesUsedToday} из ${data.aiRoutesLimit}`}.</p><p>Сообщения AI-чата сегодня: {data.aiChatLimit < 0 ? 'без дневного лимита' : `${data.aiChatUsedToday} из ${data.aiChatLimit}`}.</p><p>Роль модератора: {data.isAdmin ? 'есть' : 'нет'}</p>
        {data.plan === 'trip_pass' && <div style={{ marginTop: 14 }}>
          <button className="btn btn-quiet" type="button" onClick={() => setOfflinePreviewOpen(open => !open)} aria-expanded={offlinePreviewOpen} data-testid="button-offline-preview">Офлайн-карты</button>
          {offlinePreviewOpen && <div role="status" data-testid="offline-map-stub" style={{ marginTop: 10, padding: 14, borderRadius: 12, background: 'rgba(255,255,255,.52)' }}><strong>Предпросмотр функции</strong><p style={{ marginBottom: 0 }}>Здесь появятся пакеты карт. Загрузка карт и офлайн-навигация пока не реализованы.</p></div>}
        </div>}
        {import.meta.env.DEV && <div style={{ marginTop: 18, borderTop: '1px solid rgba(48,83,68,.2)', paddingTop: 15 }}><button className="btn btn-warm" onClick={() => pass.mutate()} disabled={pass.isPending} data-testid="button-test-trip-pass">{pass.isPending ? 'Тестируем…' : 'Тестовый Trip Pass'}</button><p>Только dev-тест интерфейса. Это не оплата и не реальная покупка.</p></div>}
        {data.isAdmin && <Link href="/admin/places" className="btn btn-quiet" data-testid="link-admin">Модерация архива <ArrowRight size={15} /></Link>}
      </aside>
    </div><Footer />
  </main>;
}

type AdminForm = {
  slug: string; nameRu: string; nameEn: string; nameUz: string; latitude: number; longitude: number;
  region: string; category: string; kind: string; summaryRu: string; summaryEn: string;
  storyRu: string; storyEn: string; practicalNotesRu: string; practicalNotesEn: string;
  imageUrls: string; tags: string; seasonality: string; accessDifficulty: string;
  verificationStatus: 'draft' | 'preliminary' | 'verified' | 'stale'; source: string;
};
const adminBlank: AdminForm = { slug: '', nameRu: '', nameEn: '', nameUz: '', latitude: 0, longitude: 0, region: '', category: '', kind: '', summaryRu: '', summaryEn: '', storyRu: '', storyEn: '', practicalNotesRu: '', practicalNotesEn: '', imageUrls: '', tags: '', seasonality: '', accessDifficulty: '', verificationStatus: 'draft', source: '' };
function adminValues(place?: Place): AdminForm {
  return place ? { slug: place.slug, nameRu: place.nameRu, nameEn: place.nameEn, nameUz: place.nameUz ?? '', latitude: place.latitude, longitude: place.longitude, region: place.region, category: place.category, kind: place.kind, summaryRu: place.summaryRu, summaryEn: place.summaryEn, storyRu: place.storyRu, storyEn: place.storyEn, practicalNotesRu: place.practicalNotesRu, practicalNotesEn: place.practicalNotesEn, imageUrls: place.imageUrls.join('\n'), tags: place.tags.join(', '), seasonality: place.seasonality.join(', '), accessDifficulty: place.accessDifficulty, verificationStatus: place.verificationStatus, source: place.source } : adminBlank;
}
async function optimizeAdminImage(file: File): Promise<File> {
  if (file.size > 25 * 1024 * 1024) throw new Error('Исходный файл больше 25 МБ.');
  if (typeof createImageBitmap !== 'function') return file;
  const bitmap = await createImageBitmap(file);
  const maxDimension = 1600;
  const scale = Math.min(1, maxDimension / bitmap.width, maxDimension / bitmap.height);
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.round(bitmap.width * scale));
  canvas.height = Math.max(1, Math.round(bitmap.height * scale));
  const context = canvas.getContext('2d');
  if (!context) { bitmap.close(); return file; }
  context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close();
  const blob = await new Promise<Blob | null>(resolve => canvas.toBlob(resolve, 'image/webp', 0.82));
  if (!blob) return file;
  const baseName = file.name.replace(/\.[^.]+$/, '') || 'wayzen-photo';
  return new File([blob], `${baseName}.webp`, { type: 'image/webp', lastModified: Date.now() });
}
function AdminPlaces() {
  const { isSignedIn } = useAuth();
  const client = useQueryClient();
  const profile = useGetProfile({ query: { queryKey: getGetProfileQueryKey(), enabled: Boolean(isSignedIn) } });
  const admin = useListAdminPlaces({ query: { queryKey: getListAdminPlacesQueryKey(), enabled: Boolean(isSignedIn && profile.data?.isAdmin) } });
  const create = useCreatePlace({ mutation: { onSuccess: () => { void client.invalidateQueries({ queryKey: getListAdminPlacesQueryKey() }); void client.invalidateQueries({ queryKey: getListPlacesQueryKey() }); } } });
  const update = useUpdatePlace({ mutation: { onSuccess: (place) => { void client.invalidateQueries({ queryKey: getListAdminPlacesQueryKey() }); void client.invalidateQueries({ queryKey: getListPlacesQueryKey() }); void client.invalidateQueries({ queryKey: getGetPlaceQueryKey(place.slug) }); } } });
  const remove = useDeletePlace({ mutation: { onSuccess: () => { void client.invalidateQueries({ queryKey: getListAdminPlacesQueryKey() }); void client.invalidateQueries({ queryKey: getListPlacesQueryKey() }); } } });
  const requestUploadUrl = useRequestUploadUrl();
  const [editing, setEditing] = useState<Place | null>(null);
  const [creating, setCreating] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState('');
  const form = useForm<AdminForm>({ defaultValues: adminBlank });
  useEffect(() => { form.reset(adminValues(editing ?? undefined)); }, [editing, creating, form]);
  const uploadPhotos = async (files: FileList | null) => {
    if (!files?.length) return;
    setUploading(true);
    setUploadError('');
    try {
      for (const original of Array.from(files)) {
        const file = await optimizeAdminImage(original);
        const allowedTypes = ['image/jpeg', 'image/png', 'image/webp'] as const;
        if (!allowedTypes.includes(file.type as typeof allowedTypes[number])) {
          throw new Error('Поддерживаются JPG, PNG и WebP.');
        }
        if (file.size > 10 * 1024 * 1024) {
          throw new Error('После сжатия фото должно быть не больше 10 МБ.');
        }
        const signed = await requestUploadUrl.mutateAsync({
          data: { name: file.name, size: file.size, contentType: file.type as typeof allowedTypes[number] },
        });
        const uploaded = await fetch(signed.uploadURL, {
          method: 'PUT',
          headers: { 'Content-Type': file.type },
          body: file,
        });
        if (!uploaded.ok) throw new Error('Хранилище не приняло фото. Попробуйте загрузить его ещё раз.');
        const path = getGetStorageObjectUrl(signed.objectPath.replace(/^\/objects\//, ''));
        const current = form.getValues('imageUrls').split('\n').map(item => item.trim()).filter(Boolean);
        if (!current.includes(path)) form.setValue('imageUrls', [...current, path].join('\n'), { shouldDirty: true });
      }
    } catch (error) {
      setUploadError(showErrorText(error));
    } finally {
      setUploading(false);
    }
  };
  if (!isSignedIn) return <main className="wrap load-shell"><EmptyState icon={<ShieldAlert />} title="Нужен вход" copy="Модерация доступна только авторизованным пользователям с ролью администратора." action={<Link className="btn btn-primary" href="/sign-in">Войти</Link>} /></main>;
  if (profile.isLoading) return <main className="wrap load-shell"><div className="skeleton" style={{ height: 250 }} /></main>;
  if (!profile.data?.isAdmin) return <main className="wrap load-shell"><EmptyState icon={<ShieldAlert />} title="Доступ закрыт" copy="У этого аккаунта нет прав модератора." action={<Link className="btn btn-quiet" href="/">На главную</Link>} /></main>;
  const submit = form.handleSubmit(values => {
    const common = {
      nameRu: values.nameRu, nameEn: values.nameEn, nameUz: values.nameUz || null, latitude: Number(values.latitude), longitude: Number(values.longitude),
      region: values.region, category: values.category, kind: values.kind, summaryRu: values.summaryRu, summaryEn: values.summaryEn,
      storyRu: values.storyRu, storyEn: values.storyEn, practicalNotesRu: values.practicalNotesRu, practicalNotesEn: values.practicalNotesEn,
      imageUrls: values.imageUrls.split('\n').map(item => item.trim()).filter(Boolean), tags: values.tags.split(',').map(item => item.trim()).filter(Boolean),
      seasonality: values.seasonality.split(',').map(item => item.trim()).filter(Boolean), accessDifficulty: values.accessDifficulty,
      verificationStatus: values.verificationStatus, source: values.source,
    };
    if (editing) { const { nameRu, nameEn, ...rest } = common; const patch: PlaceUpdate = { ...rest, nameRu, nameEn }; update.mutate({ slug: editing.slug, data: patch }); }
    else { const data: PlaceInput = { slug: values.slug, ...common }; create.mutate({ data }); }
    setEditing(null); setCreating(false);
  });
  const busy = create.isPending || update.isPending;
  return <main className="wrap">
    <div className="intro"><span className="eyebrow">WayZen · администрация</span><h1 className="display">Модерация мест.</h1><p>Изменения архивных записей сохраняются через модерационные API. Статус «проверено» должен означать реальную редакционную проверку, а не косметическое действие.</p></div>
    <ArchiveNotice compact />
    <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, alignItems: 'center', marginTop: 18 }}><span className="unverified">{admin.data?.length ?? 0} записей · проверка данных обязательна</span><button className="btn btn-primary" onClick={() => { setEditing(null); setCreating(true); }} data-testid="button-create-place"><Plus size={15} />Новая запись</button></div>
    {(creating || editing) && <section className="panel" style={{ marginTop: 16 }}><div className="section-head"><h2>{editing ? `Изменить: ${placeName(editing)}` : 'Новая запись'}</h2><button className="icon-btn" onClick={() => { setEditing(null); setCreating(false); }} aria-label="Закрыть редактор" data-testid="button-close-editor"><X size={17} /></button></div>
      <Form {...form}><form onSubmit={submit} data-testid="form-admin-place"><div className="form-grid">
        {([
          ['slug', 'Slug'], ['nameRu', 'Название (RU)'], ['nameEn', 'Название (EN)'], ['nameUz', 'Название (UZ)'], ['latitude', 'Широта'], ['longitude', 'Долгота'], ['region', 'Область'], ['category', 'Категория'], ['kind', 'Тип'], ['accessDifficulty', 'Доступность (исходная запись)'], ['source', 'Источник'],
          ['summaryRu', 'Описание (RU)'], ['summaryEn', 'Описание (EN)'], ['storyRu', 'История (RU)'], ['storyEn', 'История (EN)'], ['practicalNotesRu', 'Заметки (RU)'], ['practicalNotesEn', 'Заметки (EN)'], ['tags', 'Теги, через запятую'], ['seasonality', 'Сезонность, через запятую'], ['imageUrls', 'Ссылки на фото, по одной на строку'],
        ] as const).map(([name, label]) => <FormField key={name} control={form.control} name={name} render={({ field }) => <FormItem className="field-label"><FormLabel>{label}</FormLabel><FormControl>{name === 'storyRu' || name === 'storyEn' || name.includes('Notes') || name.includes('summary') || name === 'imageUrls' ? <textarea className="textarea" {...field} value={String(field.value ?? '')} data-testid={`input-admin-${name}`} /> : <input className="field" {...field} type={name === 'latitude' || name === 'longitude' ? 'number' : 'text'} step={name === 'latitude' || name === 'longitude' ? 'any' : undefined} value={String(field.value ?? '')} data-testid={`input-admin-${name}`} />}</FormControl></FormItem>} />)}
        <FormField control={form.control} name="verificationStatus" render={({ field }) => <FormItem className="field-label"><FormLabel>Статус проверки</FormLabel><FormControl><select className="select" {...field} data-testid="select-admin-verification"><option value="draft">Черновик</option><option value="preliminary">Предварительно</option><option value="verified">Проверено</option><option value="stale">Устарело</option></select></FormControl></FormItem>} />
        <div className="field-label" style={{ gridColumn: '1 / -1' }}>
          <label htmlFor="admin-photo-upload">Загрузить фото</label>
          <input id="admin-photo-upload" className="field" type="file" accept="image/jpeg,image/png,image/webp" multiple disabled={uploading} onChange={event => { void uploadPhotos(event.target.files); event.target.value = ''; }} data-testid="input-admin-photo-upload" />
          <small>Фото уменьшается до 1600 px и WebP, затем загружается прямо в App Storage. JPG, PNG или WebP; до 10 МБ после сжатия.</small>
          {uploading && <p role="status">Оптимизируем и загружаем фото…</p>}
          {uploadError && <p role="alert" data-testid="status-admin-photo-error">{uploadError}</p>}
        </div>
      </div><button type="submit" disabled={busy || uploading} className="btn btn-primary" data-testid="button-save-place">{busy ? 'Сохраняем…' : uploading ? 'Загружаем фото…' : 'Сохранить запись'}</button></form></Form>
    </section>}
    {admin.isLoading ? <div className="load-shell"><div className="skeleton" style={{ height: 280 }} /></div> : admin.isError ? <div style={{ marginTop: 16 }}><LoadError error={admin.error} onRetry={() => void admin.refetch()} /></div> :
      admin.data?.length ? <section className="section">{admin.data.map(place => <div className="trip-row" key={place.slug}><span className="trip-index"><MapPin size={18} /></span><span className="trip-copy"><strong>{placeName(place)}</strong><span>{place.slug} · {place.region} · {place.verificationStatus}</span></span><button className="btn btn-quiet" onClick={() => { setCreating(false); setEditing(place); }} data-testid={`button-edit-place-${place.slug}`}>Изменить</button><button className="icon-btn" aria-label="Удалить место" onClick={() => { if (window.confirm(`Удалить запись «${placeName(place)}»?`)) remove.mutate({ slug: place.slug }); }} data-testid={`button-delete-place-${place.slug}`}><Trash2 size={16} /></button></div>)}</section> :
        <div style={{ marginTop: 18 }}><EmptyState icon={<MapPin />} title="Архив пока пуст" copy="Добавьте первую запись только на основе подтверждённого источника." /></div>}
    <Footer />
  </main>;
}

function UserPortal() {
  const profile = useGetProfile({ query: { queryKey: getGetProfileQueryKey(), enabled: true } });
  return <main className="wrap"><div className="intro"><span className="eyebrow">Личный портал</span><h1 className="display">Ваш путь начинается здесь.</h1><p>Сохранённые поездки, личные интересы и архивные зацепки — в одном месте.</p></div>
    {profile.isLoading ? <div className="skeleton" style={{ height: 160 }} /> : profile.isError ? <LoadError error={profile.error} onRetry={() => void profile.refetch()} /> : <div className="feature-band"><div><span className="eyebrow">План аккаунта</span><h2>{profile.data?.plan === 'trip_pass' ? 'Trip Pass' : 'WayZen Free'}</h2><p>Маршруты сегодня: {profile.data?.aiRoutesLimit === -1 ? 'без лимита' : `${profile.data?.aiRoutesUsedToday ?? 0} из ${profile.data?.aiRoutesLimit ?? 1}`}. AI-чат: {profile.data?.aiChatLimit === -1 ? 'без лимита' : `${profile.data?.aiChatUsedToday ?? 0} из ${profile.data?.aiChatLimit ?? 10}`} сообщений. Идеи требуют самостоятельной проверки.</p></div><Link href="/trips" className="btn btn-primary" data-testid="link-portal-trips">Открыть поездки <ArrowRight size={15} /></Link></div>}
    <div className="section"><div className="feature-actions"><Link className="btn btn-quiet" href="/favorites">Избранное</Link><Link className="btn btn-quiet" href="/profile">Предпочтения</Link><Link className="btn btn-quiet" href="/planner">Новый план</Link></div></div><Footer />
  </main>;
}

function Onboarding() {
  const { isSignedIn } = useAuth();
  const [, setLocation] = useLocation();
  const client = useQueryClient();
  const profile = useGetProfile({ query: { queryKey: getGetProfileQueryKey(), enabled: Boolean(isSignedIn) } });
  const update = useUpdateProfile({ mutation: { onSuccess: () => { void client.invalidateQueries({ queryKey: getGetProfileQueryKey() }); setLocation('/user-portal'); } } });
  const form = useForm<ProfileForm>({ defaultValues: { interests: [], pace: 'slow', budget: 'moderate', travelStyle: '' } });
  useEffect(() => { if (profile.data) form.reset({ interests: profile.data.interests, pace: profile.data.pace, budget: profile.data.budget, travelStyle: profile.data.travelStyle }); }, [profile.data?.interests.join('|'), profile.data?.pace, profile.data?.budget, profile.data?.travelStyle]);
  if (!isSignedIn) return <main className="wrap load-shell"><div className="empty"><div className="empty-icon"><Compass size={22} /></div><span className="eyebrow">Начало пути</span><h2>Сначала создайте аккаунт.</h2><p>Подбор предпочтений привяжется к вашему WayZen-профилю. Каталог остаётся доступным без входа.</p><Link className="btn btn-primary" href="/sign-up" data-testid="link-onboarding-sign-up">Создать аккаунт <ArrowRight size={15} /></Link></div></main>;
  if (profile.isLoading) return <main className="wrap load-shell"><div className="skeleton" style={{ height: 360, borderRadius: 20 }} /></main>;
  if (profile.isError) return <main className="wrap load-shell"><LoadError error={profile.error} onRetry={() => void profile.refetch()} /></main>;
  return <main className="wrap">
    <div className="intro"><span className="eyebrow">01 / 01 · Знакомство</span><h1 className="display">Как вы любите путешествовать?</h1><p>Выберите несколько ориентиров — их всегда можно изменить позже. WayZen использует их для генерации идей и ничего не обещает о фактической доступности.</p></div>
    <div className="profile-grid"><section className="panel"><Form {...form}><form onSubmit={form.handleSubmit(values => update.mutate({ data: values }))} data-testid="form-onboarding">
      <FormField control={form.control} name="interests" render={({ field }) => <FormItem className="field-label"><FormLabel>Что вас притягивает?</FormLabel><div className="check-row">{interestsList.map(item => <label className="check-chip" key={item}><input type="checkbox" checked={field.value.includes(item)} onChange={event => field.onChange(event.target.checked ? [...field.value, item] : field.value.filter(value => value !== item))} data-testid={`onboarding-interest-${item}`} />{item}</label>)}</div></FormItem>} />
      <div className="form-grid"><FormField control={form.control} name="pace" render={({ field }) => <FormItem className="field-label"><FormLabel>Ваш темп</FormLabel><FormControl><select className="select" {...field} data-testid="onboarding-pace"><option value="slow">Медленный</option><option value="balanced">Сбалансированный</option><option value="packed">Насыщенный</option></select></FormControl></FormItem>} /><FormField control={form.control} name="budget" render={({ field }) => <FormItem className="field-label"><FormLabel>Предпочтение бюджета</FormLabel><FormControl><select className="select" {...field} data-testid="onboarding-budget"><option value="budget">Бюджетный</option><option value="moderate">Умеренный</option><option value="comfort">Комфорт</option></select></FormControl></FormItem>} /></div>
      <FormField control={form.control} name="travelStyle" render={({ field }) => <FormItem className="field-label"><FormLabel>Свободная заметка</FormLabel><FormControl><textarea className="textarea" maxLength={240} {...field} placeholder="Например: хочется больше времени на месте, меньше переездов" data-testid="onboarding-style" /></FormControl><FormMessage /></FormItem>} />
      {update.isError && <div style={{ marginTop: 12 }}><LoadError error={update.error} onRetry={() => void form.handleSubmit(values => update.mutate({ data: values }))()} /></div>}
      <div className="feature-actions" style={{ marginTop: 18 }}><Link className="btn btn-quiet" href="/places" data-testid="link-skip-onboarding">Пока пропустить</Link><button className="btn btn-primary" type="submit" disabled={update.isPending} data-testid="button-save-onboarding">{update.isPending ? 'Сохраняем…' : 'Сохранить и продолжить'}<ArrowRight size={15} /></button></div>
    </form></Form></section>
      <aside className="status-card"><span className="eyebrow">Честное начало</span><h2 style={{ font: '600 26px var(--app-font-serif)' }}>Никаких выдуманных деталей.</h2><p>Все импортированные места — предварительные. Время поездки, условия посещения, цены и часы работы нужно проверить у актуальных источников.</p><Link href="/places" className="btn btn-quiet" data-testid="link-onboarding-archive">Пока просто посмотреть <ArrowRight size={15} /></Link></aside>
    </div><Footer />
  </main>;
}

function HomeRedirect() {
  const { isSignedIn, isLoaded } = useAuth();
  if (isLoaded && isSignedIn) return <Redirect to="/user-portal" />;
  return <Home />;
}
function ProtectedPortalRoute({ children }: { children: ReactNode }) {
  const { isSignedIn, isLoaded } = useAuth();
  if (!isLoaded) return <main className="wrap load-shell"><div className="skeleton" style={{ height: 190 }} /></main>;
  return isSignedIn ? <>{children}</> : <Redirect to="/" />;
}
function SignInPage() {
  return <AuthScreen><SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} /></AuthScreen>;
}
function SignUpPage() {
  return <AuthScreen><SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} /></AuthScreen>;
}
function AuthScreen({ children }: { children: ReactNode }) {
  return <main className="auth-wrap"><section className="auth-story"><Brand /><div><span className="eyebrow" style={{ color: '#e7c791' }}>WayZen · Uzbekistan</span><h1>Travel at your own pace.</h1><p>Start with an honest archive of places and shape your own independent journey.</p></div><span className="eyebrow" style={{ color: '#d9e6d7' }}>PRELIMINARY PLACES · SELF-GUIDED IDEAS</span></section><section className="auth-card">{children}</section></main>;
}
function ClerkCacheInvalidator() {
  const { addListener } = useClerk();
  const client = useQueryClient();
  const lastUser = useRef<string | null | undefined>(undefined);
  useEffect(() => addListener(({ user }) => { const id = user?.id ?? null; if (lastUser.current !== undefined && id !== lastUser.current) client.clear(); lastUser.current = id; }), [addListener, client]);
  return null;
}
function Footer() {
  const health = useHealthCheck({ query: { queryKey: getHealthCheckQueryKey(), staleTime: 60_000 } });
  return <footer className="footer"><div className="footer-inner"><span>WAYZEN · Uzbekistan, at your own pace.</span><span>16 preliminary archive entries · not verified · confirm conditions locally.</span><span data-testid="status-api-health">{health.isLoading ? 'Проверяем подключение…' : health.isError ? 'Сервис сейчас недоступен' : `API: ${health.data?.status ?? 'готов'}`}</span></div></footer>;
}

function SiteRouter() {
  const favorites = useFavoritesState();
  const [currentPath, setLocation] = useLocation();
  const { isSignedIn } = useAuth();
  const isAuthPath = currentPath.startsWith('/sign-in') || currentPath.startsWith('/sign-up');
  return <div className="shell">{!isAuthPath && <Header favoriteCount={favorites.values.length} />}
    <Switch>
      <Route path="/" component={HomeRedirect} />
      <Route path="/sign-in/*?" component={SignInPage} />
      <Route path="/sign-up/*?" component={SignUpPage} />
      <Route path="/places" component={Catalog} />
      <Route path="/place/:slug" component={PlaceDetail} />
      <Route path="/map" component={MapPage} />
      <Route path="/planner" component={Planner} />
      <Route path="/favorites" component={Favorites} />
      <Route path="/trips" component={Trips} />
      <Route path="/trips/:id">{() => <TripDetail />}</Route>
      <Route path="/ai" component={AIChat} />
      <Route path="/profile">{() => <ProtectedPortalRoute><ProfilePage /></ProtectedPortalRoute>}</Route>
      <Route path="/onboarding" component={Onboarding} />
      <Route path="/user-portal">{() => <ProtectedPortalRoute><UserPortal /></ProtectedPortalRoute>}</Route>
      <Route path="/admin/places">{() => <ProtectedPortalRoute><AdminPlaces /></ProtectedPortalRoute>}</Route>
      <Route>{() => <NotFound navigate={() => setLocation('/')} signedIn={Boolean(isSignedIn)} />}</Route>
    </Switch>
  </div>;
}
function NotFound({ navigate, signedIn }: { navigate: () => void; signedIn: boolean }) {
  return <main className="wrap load-shell"><EmptyState icon={<CircleHelp size={22} />} title="Такой страницы нет" copy="Попробуйте вернуться к атласу или личному порталу." action={<button className="btn btn-primary" onClick={navigate} data-testid="button-not-found-home">{signedIn ? 'В личный портал' : 'На главную'} <ArrowRight size={15} /></button>} /></main>;
}
function ClerkRoutes() {
  const [, setLocation] = useLocation();
  return <ClerkProvider
    publishableKey={clerkPubKey}
    proxyUrl={clerkProxyUrl}
    appearance={{
      theme: shadcn, cssLayerName: 'clerk',
      options: { logoPlacement: 'inside', logoLinkUrl: basePath || '/', logoImageUrl: `${window.location.origin}${basePath}/logo.svg` },
      variables: { colorPrimary: '#1c6556', colorForeground: '#214f45', colorMutedForeground: '#697970', colorDanger: '#a64d3e', colorBackground: '#faf8ef', colorInput: '#fffdf6', colorInputForeground: '#214f45', colorNeutral: '#d9d8ca', fontFamily: 'DM Sans, sans-serif', borderRadius: '0.85rem' },
      elements: {
        rootBox: 'w-full flex justify-center',
        cardBox: 'bg-[#faf8ef] rounded-2xl w-[440px] max-w-full overflow-hidden shadow-none border border-[#dedccf]',
        card: '!shadow-none !border-0 !bg-transparent !rounded-none',
        footer: '!shadow-none !border-0 !bg-transparent !rounded-none',
        headerTitle: 'text-[#214f45] font-semibold', headerSubtitle: 'text-[#697970]',
        socialButtonsBlockButtonText: 'text-[#214f45]', formFieldLabel: 'text-[#214f45]',
        footerActionLink: 'text-[#1c6556]', footerActionText: 'text-[#697970]', dividerText: 'text-[#697970]',
        identityPreviewEditButton: 'text-[#1c6556]', formFieldSuccessText: 'text-[#286c58]', alertText: 'text-[#8e4437]',
        logoBox: 'rounded-xl', logoImage: 'object-contain', socialButtonsBlockButton: 'border-[#d9d8ca] bg-[#fffdf6]',
        formButtonPrimary: 'bg-[#1c6556] text-[#fff8e8]', formFieldInput: 'border-[#d9d8ca] bg-[#fffdf6] text-[#214f45]',
        footerAction: 'text-[#697970]', dividerLine: 'bg-[#dedccf]', alert: 'bg-[#f7e9e3]',
        otpCodeFieldInput: 'border-[#d9d8ca] bg-[#fffdf6] text-[#214f45]', formFieldRow: 'text-[#214f45]', main: 'text-[#214f45]',
      },
    }}
    signInUrl={`${basePath}/sign-in`}
    signUpUrl={`${basePath}/sign-up`}
    localization={{
      signIn: { start: { title: 'С возвращением', subtitle: 'Продолжите планировать в своём темпе' } },
      signUp: { start: { title: 'Создайте аккаунт', subtitle: 'Сохраняйте места и собственные поездки' } },
    }}
    routerPush={to => setLocation(stripBase(to))}
    routerReplace={to => setLocation(stripBase(to), { replace: true })}
  >
    <ClerkCacheInvalidator />
    <SiteRouter />
  </ClerkProvider>;
}

function App() {
  return <QueryClientProvider client={queryClient}><WouterRouter base={basePath}><ClerkRoutes /></WouterRouter></QueryClientProvider>;
}

export default App;
